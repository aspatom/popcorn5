/*--------------------
 * PWM CLK 24.5MHz
 *-------------------*/					   
#include "stm32f4xx.h"

#ifndef __TIM_H
#define __TIM_H

void TIM_IT_Config(void);

void TIM2_IT_Config(void);

#endif
